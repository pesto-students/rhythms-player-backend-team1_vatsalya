let config = {
  connectionLimit: 100,
  host: "rhythmsdb.coxqtog1rscl.ap-south-1.rds.amazonaws.com",
  port: 3306,
  user: "admin",
  password: "Admin123#",
  database: "rhythms_dev",
};

module.exports = config;
